# Netlynk - Small Business Website Service

## Overview

Netlynk is a static marketing website for a web design service that specializes in creating affordable WordPress websites for small businesses. The site features a unique "pay after delivery" business model where clients pay only for domain and hosting upfront, then pay for development services after the website is completed and live. The website serves as a landing page to attract potential customers and showcase the company's services, pricing, and contact information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

**Frontend Architecture**
- Static HTML/CSS/JavaScript website with no build process or framework dependencies
- Single-page application structure with smooth scrolling navigation between sections
- Mobile-first responsive design approach using CSS media queries
- Component-based CSS organization using custom properties (CSS variables) for consistent theming

**Design System**
- Custom CSS framework built around CSS custom properties for color scheme, typography, and spacing
- Inter font family from Google Fonts for modern typography
- Consistent visual hierarchy using predefined shadow, border-radius, and color variables
- Semantic HTML structure with proper accessibility considerations

**Navigation & User Experience**
- Fixed navigation bar with smooth scroll-to-section functionality
- Hamburger menu implementation for mobile devices
- Dynamic navbar styling that changes appearance on scroll for better visual feedback
- Client-side form handling with JavaScript for contact form submissions

**Performance Considerations**
- Minimal external dependencies (only Google Fonts)
- Optimized loading with font preconnection
- Lightweight vanilla JavaScript for interactions
- CSS-only responsive design without framework overhead

## External Dependencies

**Third-party Services**
- Google Fonts API for Inter font family loading
- Preconnected to fonts.googleapis.com and fonts.gstatic.com for performance optimization

**Hosting Requirements**
- Static hosting compatible (no server-side processing required)
- Standard web server capable of serving HTML, CSS, and JavaScript files
- No database or backend services needed for current functionality

**Browser Compatibility**
- Modern browser support required for CSS custom properties and ES6 JavaScript features
- Responsive design supports mobile and desktop viewports
- Smooth scrolling and backdrop-filter effects for enhanced user experience